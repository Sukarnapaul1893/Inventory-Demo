﻿namespace InventoryDemo.Models.ViewModels
{
    public class SaleView
    {
        public int Id { get; set; }
        public string Date { get; set; }
        public int CustomerId { get; set; }
        public int SalesmanId { get; set; }
    }
}
